#include "PluginEditor.h"

LaarLibraryAudioProcessorEditor::LaarLibraryAudioProcessorEditor(LaarLibraryAudioProcessor& p)
 : AudioProcessorEditor(&p), processor(p)
{
    setSize(760, 520);
    title.setText("LAAR LIBRARY", juce::dontSendNotification);
    title.setFont(juce::Font(juce::FontOptions(30.0f, juce::Font::bold)));
    title.setColour(juce::Label::textColourId, juce::Colour(0xffff0000));
    addAndMakeVisible(title);
    subtitle.setText("WAVETABLE SYNTH  /  WINDOWS VST3", juce::dontSendNotification);
    subtitle.setColour(juce::Label::textColourId, juce::Colours::grey);
    addAndMakeVisible(subtitle);

    category.addItemList({"israeliz", "joseadores", "cart!", "slayr", "real under"}, 1);
    category.setSelectedId(1);
    category.onChange = [this] { processor.setCurrentProgram(category.getSelectedId() - 1); };
    addAndMakeVisible(category);

    wave.addItemList({"Sine", "Saw", "Square", "Triangle"}, 1);
    addAndMakeVisible(wave);
    waveA = std::make_unique<ComboAttachment>(processor.parameters, "wave", wave);

    auto setup = [this](juce::Slider& s, const juce::String& name)
    {
        s.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
        s.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 76, 20);
        s.setColour(juce::Slider::rotarySliderFillColourId, juce::Colour(0xffff0000));
        s.setColour(juce::Slider::thumbColourId, juce::Colours::white);
        addAndMakeVisible(s);
        auto* label = new juce::Label();
        label->setText(name, juce::dontSendNotification);
        label->setJustificationType(juce::Justification::centred);
        label->setColour(juce::Label::textColourId, juce::Colours::white);
        addAndMakeVisible(label);
        labels.add(label);
    };
    setup(cutoff, "CUTOFF"); setup(resonance, "RESONANCE"); setup(drive, "DRIVE");
    setup(attack, "ATTACK"); setup(release, "RELEASE"); setup(master, "MASTER");
    cutoffA = std::make_unique<SliderAttachment>(processor.parameters, "cutoff", cutoff);
    resonanceA = std::make_unique<SliderAttachment>(processor.parameters, "resonance", resonance);
    driveA = std::make_unique<SliderAttachment>(processor.parameters, "drive", drive);
    attackA = std::make_unique<SliderAttachment>(processor.parameters, "attack", attack);
    releaseA = std::make_unique<SliderAttachment>(processor.parameters, "release", release);
    masterA = std::make_unique<SliderAttachment>(processor.parameters, "master", master);
}
void LaarLibraryAudioProcessorEditor::paint(juce::Graphics& g)
{
    g.fillAll(juce::Colour(0xff090909));
    g.setColour(juce::Colour(0xffff0000));
    g.fillRect(0, 0, getWidth(), 5);
    g.setColour(juce::Colour(0xff242424));
    g.drawRoundedRectangle(20.0f, 120.0f, (float)getWidth()-40.0f, (float)getHeight()-145.0f, 8.0f, 1.0f);
    g.setColour(juce::Colour(0xffff0000));
    g.setFont(12.0f);
    g.drawText("OSCILLATORS  /  FILTER  /  DRIVE  /  ENVELOPE", 30, 128, getWidth()-60, 24, juce::Justification::centredLeft);
}
void LaarLibraryAudioProcessorEditor::resized()
{
    title.setBounds(24, 18, 400, 42);
    subtitle.setBounds(27, 59, 400, 20);
    category.setBounds(480, 28, 250, 32);
    wave.setBounds(30, 165, 140, 28);
    juce::Slider* sliders[] = {&cutoff, &resonance, &drive, &attack, &release, &master};
    for (int i = 0; i < 6; ++i)
    {
        const int col = i % 3, row = i / 3;
        sliders[i]->setBounds(35 + col * 235, 205 + row * 135, 130, 105);
        if (i < labels.size())
            labels[i]->setBounds(20 + col * 235, 190 + row * 135, 160, 20);
    }
}
