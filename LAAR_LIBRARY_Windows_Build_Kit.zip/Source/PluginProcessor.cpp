#include "PluginProcessor.h"
#include "PluginEditor.h"

namespace
{
class LaarVoice final : public juce::SynthesiserVoice
{
public:
    bool canPlaySound(juce::SynthesiserSound* sound) override
    { return dynamic_cast<juce::SynthesiserSound*>(sound) != nullptr; }

    void startNote(int midiNote, float velocity, juce::SynthesiserSound*, int) override
    {
        level = velocity;
        phase = 0.0;
        const auto hz = juce::MidiMessage::getMidiNoteInHertz(midiNote);
        increment = hz / getSampleRate();
        env = 0.0f;
        releasing = false;
        active = true;
    }
    void stopNote(float, bool allowTailOff) override
    {
        if (allowTailOff) releasing = true;
        else { clearCurrentNote(); active = false; }
    }
    void pitchWheelMoved(int) override {}
    void controllerMoved(int, int) override {}
    void renderNextBlock(juce::AudioBuffer<float>& output, int start, int count) override
    {
        if (!active || getSampleRate() <= 0.0) return;
        auto* left = output.getWritePointer(0);
        auto* right = output.getNumChannels() > 1 ? output.getWritePointer(1) : nullptr;
        const auto wave = (int) processorWave->load();
        const auto attack = juce::jmax(0.001f, processorAttack->load());
        const auto release = juce::jmax(0.01f, processorRelease->load());
        for (int i = 0; i < count; ++i)
        {
            if (!releasing) env = juce::jmin(1.0f, env + 1.0f / (attack * (float)getSampleRate()));
            else
            {
                env *= std::exp(-1.0f / (release * (float)getSampleRate()));
                if (env < 0.0001f) { active = false; clearCurrentNote(); break; }
            }
            float sample = 0.0f;
            if (wave == 0) sample = std::sin((float)(phase * juce::MathConstants<double>::twoPi));
            else if (wave == 1) sample = (float)(2.0 * phase - 1.0);
            else if (wave == 2) sample = phase < 0.5 ? 1.0f : -1.0f;
            else sample = 2.0f * std::abs(2.0f * (float)phase - 1.0f) - 1.0f;
            sample *= level * env * 0.18f;
            left[start + i] += sample;
            if (right) right[start + i] += sample;
            phase += increment;
            if (phase >= 1.0) phase -= 1.0;
        }
    }

    std::atomic<float>* processorWave = nullptr;
    std::atomic<float>* processorAttack = nullptr;
    std::atomic<float>* processorRelease = nullptr;
private:
    double phase = 0.0, increment = 0.0;
    float level = 0.0f, env = 0.0f;
    bool releasing = false, active = false;
};
class LaarSound final : public juce::SynthesiserSound
{
public:
    bool appliesToNote(int) override { return true; }
    bool appliesToChannel(int) override { return true; }
};
}

juce::AudioProcessorValueTreeState::ParameterLayout LaarLibraryAudioProcessor::createParameterLayout()
{
    juce::AudioProcessorValueTreeState::ParameterLayout p;
    p.add(std::make_unique<juce::AudioParameterChoice>("wave", "OSC Wave",
        juce::StringArray{"Sine", "Saw", "Square", "Triangle"}, 1));
    p.add(std::make_unique<juce::AudioParameterFloat>("cutoff", "Filter Cutoff",
        juce::NormalisableRange<float>(80.0f, 18000.0f, 1.0f, 0.35f), 12000.0f));
    p.add(std::make_unique<juce::AudioParameterFloat>("resonance", "Resonance",
        juce::NormalisableRange<float>(0.1f, 1.0f, 0.001f), 0.2f));
    p.add(std::make_unique<juce::AudioParameterFloat>("drive", "Drive",
        juce::NormalisableRange<float>(0.0f, 1.0f, 0.001f), 0.0f));
    p.add(std::make_unique<juce::AudioParameterFloat>("attack", "Attack",
        juce::NormalisableRange<float>(0.001f, 2.0f, 0.001f, 0.4f), 0.01f));
    p.add(std::make_unique<juce::AudioParameterFloat>("release", "Release",
        juce::NormalisableRange<float>(0.01f, 4.0f, 0.001f, 0.4f), 0.35f));
    p.add(std::make_unique<juce::AudioParameterFloat>("master", "Master",
        juce::NormalisableRange<float>(0.0f, 1.0f, 0.001f), 0.75f));
    return p;
}

LaarLibraryAudioProcessor::LaarLibraryAudioProcessor()
 : AudioProcessor(BusesProperties().withOutput("Output", juce::AudioChannelSet::stereo(), true)),
   parameters(*this, nullptr, "LAAR_PARAMS", createParameterLayout())
{
    for (int i = 0; i < 16; ++i)
    {
        auto* voice = new LaarVoice();
        voice->processorWave = parameters.getRawParameterValue("wave");
        voice->processorAttack = parameters.getRawParameterValue("attack");
        voice->processorRelease = parameters.getRawParameterValue("release");
        synth.addVoice(voice);
    }
    synth.addSound(new LaarSound());
}

void LaarLibraryAudioProcessor::prepareToPlay(double sampleRate, int samplesPerBlock)
{
    synth.setCurrentPlaybackSampleRate(sampleRate);
    juce::dsp::ProcessSpec spec{sampleRate, (juce::uint32)samplesPerBlock, 1};
    filterL.prepare(spec); filterR.prepare(spec);
    filterL.setType(juce::dsp::StateVariableTPTFilterType::lowpass);
    filterR.setType(juce::dsp::StateVariableTPTFilterType::lowpass);
}

bool LaarLibraryAudioProcessor::isBusesLayoutSupported(const BusesLayout& layouts) const
{
    return layouts.getMainOutputChannelSet() == juce::AudioChannelSet::mono()
        || layouts.getMainOutputChannelSet() == juce::AudioChannelSet::stereo();
}

void LaarLibraryAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midi)
{
    juce::ScopedNoDenormals noDenormals;
    buffer.clear();
    synth.renderNextBlock(buffer, midi, 0, buffer.getNumSamples());

    const auto cutoff = parameters.getRawParameterValue("cutoff")->load();
    const auto resonance = parameters.getRawParameterValue("resonance")->load();
    const auto drive = parameters.getRawParameterValue("drive")->load();
    const auto master = parameters.getRawParameterValue("master")->load();
    filterL.setCutoffFrequency(cutoff); filterR.setCutoffFrequency(cutoff);
    filterL.setResonance(resonance); filterR.setResonance(resonance);

    for (int ch = 0; ch < buffer.getNumChannels(); ++ch)
    {
        auto* data = buffer.getWritePointer(ch);
        auto& filter = ch == 0 ? filterL : filterR;
        for (int i = 0; i < buffer.getNumSamples(); ++i)
        {
            float x = filter.processSample(data[i]);
            x = std::tanh(x * (1.0f + drive * 18.0f));
            data[i] = x * master;
        }
    }
}

void LaarLibraryAudioProcessor::setCurrentProgram(int index)
{
    currentProgram = juce::jlimit(0, 4, index);
    loadCategoryPreset(currentProgram);
}
const juce::String LaarLibraryAudioProcessor::getProgramName(int index)
{
    const juce::StringArray names{"israeliz", "joseadores", "cart!", "slayr", "real under"};
    return names[juce::jlimit(0, names.size() - 1, index)];
}
void LaarLibraryAudioProcessor::loadCategoryPreset(int index)
{
    const float cutoffs[] = {15000.0f, 9000.0f, 6500.0f, 11000.0f, 4200.0f};
    const float drives[] = {0.05f, 0.18f, 0.35f, 0.55f, 0.9f};
    *parameters.getRawParameterValue("cutoff") = cutoffs[juce::jlimit(0,4,index)];
    *parameters.getRawParameterValue("drive") = drives[juce::jlimit(0,4,index)];
    *parameters.getRawParameterValue("wave") = index < 2 ? 1.0f : 2.0f;
}
void LaarLibraryAudioProcessor::getStateInformation(juce::MemoryBlock& destData)
{
    auto state = parameters.copyState();
    std::unique_ptr<juce::XmlElement> xml(state.createXml());
    copyXmlToBinary(*xml, destData);
}
void LaarLibraryAudioProcessor::setStateInformation(const void* data, int sizeInBytes)
{
    std::unique_ptr<juce::XmlElement> xml(getXmlFromBinary(data, sizeInBytes));
    if (xml && xml->hasTagName(parameters.state.getType()))
        parameters.replaceState(juce::ValueTree::fromXml(*xml));
}
juce::AudioProcessorEditor* LaarLibraryAudioProcessor::createEditor()
{ return new LaarLibraryAudioProcessorEditor(*this); }

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{ return new LaarLibraryAudioProcessor(); }
