#pragma once
#include <JuceHeader.h>
#include "PluginProcessor.h"

class LaarLibraryAudioProcessorEditor final : public juce::AudioProcessorEditor
{
public:
    explicit LaarLibraryAudioProcessorEditor(LaarLibraryAudioProcessor&);
    void paint(juce::Graphics&) override;
    void resized() override;
private:
    LaarLibraryAudioProcessor& processor;
    juce::ComboBox category, wave;
    juce::Slider cutoff, resonance, drive, attack, release, master;
    juce::Label title, subtitle;
    juce::OwnedArray<juce::Label> labels;
    using SliderAttachment = juce::AudioProcessorValueTreeState::SliderAttachment;
    using ComboAttachment = juce::AudioProcessorValueTreeState::ComboBoxAttachment;
    std::unique_ptr<SliderAttachment> cutoffA, resonanceA, driveA, attackA, releaseA, masterA;
    std::unique_ptr<ComboAttachment> waveA;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(LaarLibraryAudioProcessorEditor)
};
