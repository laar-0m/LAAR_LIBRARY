@echo off
setlocal
where cmake >nul 2>nul || (echo ERROR: Instala CMake y agregalo al PATH.& pause & exit /b 1)
where git >nul 2>nul || (echo ERROR: Instala Git y agregalo al PATH.& pause & exit /b 1)
echo Configurando LAAR LIBRARY para Windows x64...
cmake -S . -B build -A x64
if errorlevel 1 goto fail
echo Compilando VST3 Release...
cmake --build build --config Release --target LaarLibrary_VST3
if errorlevel 1 goto fail
echo.
echo Build terminado. Busca el plugin dentro de:
echo build\LaarLibrary_artefacts\Release\VST3\
echo Copia la carpeta completa .vst3 a %%COMMONPROGRAMFILES%%\VST3\
pause
exit /b 0
:fail
echo.
echo La compilacion fallo. Verifica Visual Studio 2022 con Desktop development with C++ y conexion a internet.
pause
exit /b 1
