# LAAR LIBRARY — VST3 starter

Proyecto inicial de sintetizador para Windows con JUCE y CMake. Incluye una voz polifónica básica, formas de onda clásicas, filtro low-pass, drive/distorsión, envolvente attack/release, controles y cinco categorías iniciales: `israeliz`, `joseadores`, `cart!`, `slayr` y `real under`.

## Importante
Esto es un **prototipo inicial de código**, no un VST3 ya compilado ni un clon de Serum/Omnisphere. El motor actual usa formas de onda básicas; todavía falta implementar una verdadera tabla de ondas importable, un navegador de cientos de presets, LFOs, mod matrix, efectos completos, oversampling y pruebas de compatibilidad.

## Compilar en Windows
1. Instala Visual Studio 2022 con el workload **Desktop development with C++**.
2. Instala Git y CMake.
3. Abre x64 Native Tools Command Prompt for VS 2022.
4. Desde esta carpeta ejecuta:
   ```bat
   cmake -S . -B build -A x64
   cmake --build build --config Release
   ```
5. El VST3 se generará en una ruta dentro de `build` que termina en `LaarLibrary_artefacts/Release/VST3/`.

CMake descargará JUCE desde su repositorio oficial, así que necesitas conexión a internet durante la configuración inicial.

## Próximas fases recomendadas
- Wavetable real con importación WAV y lectura interpolada.
- Segundo oscilador, sub oscillator, unison y detune.
- LFOs y matriz de modulación arrastrable.
- Reverb, delay, chorus, compressor y bitcrush.
- Banco amplio de presets originales por categoría, con tags de género.
- Instalador y pruebas en FL Studio, Ableton Live, Reaper y otros hosts VST3.


## Compilación más sencilla
En Windows con Visual Studio 2022 (Desktop development with C++), CMake y Git instalados, ejecuta `build_windows.bat`. El archivo final se crea como bundle `.vst3`. También se incluye un workflow de GitHub Actions (`.github/workflows/build-windows.yml`) para compilar en una máquina Windows de GitHub y descargar el artefacto desde Actions.
